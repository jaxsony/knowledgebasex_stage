import React from 'react'

const LastBanner = () => {
  return (
    <div>
      Last Banner
    </div>
  )
}

export default LastBanner
