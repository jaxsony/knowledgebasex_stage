export const COURSEPLAN="COURSEPLAN";
export const PLAN = "PLAN";
export const PACKAGE = "PACKAGE";
export const PHONE = "PHONE"
